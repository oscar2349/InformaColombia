package com.springboot.backend.andres.usersapp.usersbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UsersBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
