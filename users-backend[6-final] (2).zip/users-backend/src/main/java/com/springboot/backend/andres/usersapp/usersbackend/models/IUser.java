package com.springboot.backend.andres.usersapp.usersbackend.models;

public interface IUser {

    boolean isAdmin();
}
